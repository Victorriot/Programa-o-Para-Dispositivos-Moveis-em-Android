clear
printf "==============  Iniciando o Projeto =============="
printf "\n" 
printf "\n" 
./run/linux/dependencies.sh
printf "\n" 
printf "\n" 
./run/linux/run.sh
printf "\n" 