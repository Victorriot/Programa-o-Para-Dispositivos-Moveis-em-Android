# clear
printf "==============  Construido o Projeto =============="
printf "\n"
printf "\n"
npm run start
printf "\n"
printf "\n" 